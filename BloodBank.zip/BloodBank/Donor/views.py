from django.shortcuts import render,redirect, get_object_or_404
from Guest.models import *
from Guest.models import *
from Bloodbankapp.models import *
from Donor.models import *
from Administrator.models import *
from Patient.models import *


# Create your views here.
def myprofile(request):
    donor=tbl_donor.objects.get(id=request.session['did'])
    return render(request,"Donor/Myprofile.html",{'data':donor})

def editprofile(request):
    donor=tbl_donor.objects.get(id=request.session['did'])
    if request.method == "POST":
        donor.donor_name=request.POST.get("txtname")
        donor.donor_email=request.POST.get("txtemail")
        donor.donor_contact=request.POST.get("txtphone")
        
        donor.save()
        return redirect("Donor:myprofile")
    else:
        return render(request,"Donor/EditProfile.html",{'data':donor})
    

def changepassword(request):
    donor=tbl_donor.objects.get(id=request.session['did'])
    dbpassword=donor.donor_password
    if request.method == "POST":
        oldpassword=request.POST.get("txt_oldpassword")
        newpassword=request.POST.get("txt_newpassword")
        conformpassword=request.POST.get("txt_cpassword")
        if dbpassword == oldpassword:
            if newpassword == conformpassword:
                donor.donor_password=newpassword
                donor.save()
                return redirect("Donor:myprofile")
            else:
                return render(request,"Donor/ChangePassword.html",{'msg':"Password MisMatch "})
        else:
            return render(request,"Donor/ChangePassword.html",{'msg':"Password Incorect "})
    else:
        return render(request,"Donor/ChangePassword.html")
    



#donation history

def donationhistory(request):
    bloodunit=tbl_blooddonate.objects.filter(donor=request.session['did'])
    return render(request,'Donor/DonationHistory.html',{'bloodunit':bloodunit})




#camp details 

def campdetails (request):
    data=tbl_camp.objects.all()
    return render(request,'Donor/CampDetails.html',{'data':data})
# complaint send 

def complaintnew(request):


    if request.method == "POST":
        content = request.POST.get("txtconm")
        tbl_complaint.objects.create(complaint_content=content,donor=tbl_donor.objects.get(id=request.session['did']))
        return redirect('Donor:complaintnew')  # Redirect to clear form data
    else:
        return render(request,'Donor/Complaint.html')
    

#logout 
def logout(request):
    del request.session["did"]
    return redirect("Guest:index")




# def donor_request(request):
#     hon = tbl_request.objects.filter(request_status = 3)
    
#     gon = tbl_blooddonate.objects.all()
#     for j in hon :
#         for i in gon :
#             if i.bloodgroup.Bloodgroup_name  == j.donor.bloodgroup.Bloodgroup_name:
#                 return render(request,"Donor/Request.html",{"hon":hon} )
                

#     first nice 

# def donor_request(request):
#     # Get all requests where request_status is 3
#     matching_requests = tbl_request.objects.filter(request_status=3)

#     # Filter requests where the bloodgroup matches with a donor's bloodgroup
#     valid_requests = []
    
#     for req in matching_requests:
#         # Check if there exists a donor in tbl_blooddonate with the same blood group
#         if tbl_blooddonate.objects.filter(donor=request.session["did"],donor__bloodgroup=req.bloodgroup).exists():
#             valid_requests.append(req)

#     return render(request, "Donor/Request.html", {"hon": valid_requests})





#request 

# def donor_request(request):
#     donor_id = request.session.get("did")
#     if not donor_id:
#         return redirect("Guest:login")  # Redirect if session is missing
    
#     donor = get_object_or_404(tbl_donor, id=donor_id)
#     req = tbl_request.objects.filter(request_status=3, bloodgroup=donor.bloodgroup.id, place=donor.place.id)
    
#     return render(request, "Donor/Request.html", {"blood_requests": req})

# def acceptrequest(request, id):
#     req = get_object_or_404(tbl_request, id=id)
#     donor_id = request.session.get("did")
#     if not donor_id:
#         return redirect("Guest:login")  # Redirect if session is missing
    
#     req.request_status = 4
#     req.donor = get_object_or_404(tbl_donor, id=donor_id)
#     req.save()
    
#     return render(request, "Donor/Request.html", {"msg": "You accepted the request"})

# def myaccepted(request):
#     donor_id = request.session.get("did")
#     if not donor_id:
#         return redirect("Guest:login")  # Redirect if session is missing
    
#     donor = get_object_or_404(tbl_donor, id=donor_id)
#     req = tbl_request.objects.filter(donor=donor, request_status=4)
    
#     return render(request, "Donor/AcceptedRequest.html", {"request": req})

def donor_request(request): 
    donor = tbl_donor.objects.get(id=request.session["did"])
    req = tbl_request.objects.filter(request_status=3,bloodgroup=donor.bloodgroup.id)
    return render(request, "Donor/Request.html",{"blood_requests":req})
    
    
    # ,place=donor.place.id
    
    
# def donor_request(request):
#     donor_id = request.session.get("did")
#     if not donor_id:
#         return render(request, "error.html", {"message": "Donor not found in session."})

#     donor = get_object_or_404(tbl_donor, id=donor_id)

#     req = tbl_request.objects.filter(
#         request_status=3,
#         bloodgroup=donor.bloodgroup,
#         place=donor.place
#     )

#     return render(request, "Donor/Request.html", {"blood_requests": req})


















def acceptrequest(request, id):
    req = tbl_request.objects.get(id=id)
    req.request_status = 4
    req.donor = tbl_donor.objects.get(id=request.session["did"])
    req.save()
    return render(request, "Donor/Request.html",{"msg":"You accepted the request"})

def myaccepted(request):
    req = tbl_request.objects.filter(donor=request.session["did"],request_status=4)
    return render(request,"Donor/AcceptedRequest.html",{"request":req})


















# def donor_request(request, id):
#     approve = tbl_request.objects.get(id=id)
#     bloodgroup = approve.bloodgroup

#     # Filter donors who have the same blood group
#     reque = tbl_blooddonate.objects.filter(donor__bloodgroup=bloodgroup)

#     return render(request, "Donor/Request.html", {
#         "reque": reque,  # List of matching donors
#         "data": [approve]  # Wrapping in a list to avoid template errors
#     })




# def donor_request(request):
#     donors = tbl_blooddonate.objects.all()  # Get all donors
#     requests = tbl_request.objects.filter(request_status=3)  # Filter requests where status = 3

#     match = []

#     for donor in donors:
#         for req in requests:
#             if donor.donor.bloodgroup.Bloodgroup_name == req.patient.bloodgroup.Bloodgroup_name:
#                 match.append(req)

#     return render(request, "Donor/Request.html", {'data': match})